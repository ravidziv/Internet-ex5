Angular Unit Tests
==================

To run the test suite, run these commands:

    npm install
    npm test
